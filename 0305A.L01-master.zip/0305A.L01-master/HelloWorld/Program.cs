﻿using System;

namespace HelloWorld
{
    class Program // declaración de clase
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo!!"); // muestra una línea de texto en la ventana de comandos
        }
    }
}
